Project report in PDF
